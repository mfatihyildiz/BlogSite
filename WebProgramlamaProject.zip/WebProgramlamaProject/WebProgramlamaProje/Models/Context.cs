﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace WebProgramlamaProje.Entity
{
	public class Context : IdentityDbContext<AppUser>
    {        
        protected override void OnConfiguring ( DbContextOptionsBuilder optionsBuilder)
		{
			optionsBuilder.UseSqlServer("Server=(localdb)\\MSSQLLocalDB;Database=deneme20;Trusted_Connection=True;");
		}
		public DbSet<Admin> Admins { get; set; }
		public DbSet<Author> Authors { get; set; }	
		public DbSet<Blog> Blogs { get; set; }
		public DbSet<Category> Categories { get; set; }
		public DbSet<Comment> Comments { get; set; }

	}
}
