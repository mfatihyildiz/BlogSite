﻿namespace WebProgramlamaProje.Resources
{
    public class SharedResource
    {
    }
}
