﻿using Microsoft.AspNetCore.Mvc;

namespace WebProgramlamaProje.Controllers
{
    public class UsersController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

    }
}
