﻿using WebProgramlamaProje.Entity;

namespace WebProgramlamaProje.Repositories
{
	public class AdminRepository:GenericRepository<Admin>
	{
	}
}
