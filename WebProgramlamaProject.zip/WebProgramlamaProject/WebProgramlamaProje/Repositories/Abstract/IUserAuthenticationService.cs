﻿using WebProgramlamaProje.Entity;

namespace WebProgramlamaProje.Repositories.Abstract
{
	public interface IUserAuthenticationService
	{

		Task<Status> LoginAsync(LoginModel model);
		Task LogoutAsync();
		Task<Status> RegisterAsync(RegistrationModel model);
	
	}
}
