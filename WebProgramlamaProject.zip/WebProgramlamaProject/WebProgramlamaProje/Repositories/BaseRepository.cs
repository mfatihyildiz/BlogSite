﻿using static WebProgramlamaProje.Repositories.Abstract.IGnericRepository;
using System.Linq.Expressions;
using WebProgramlamaProje.Entity;
using Microsoft.EntityFrameworkCore;

namespace WebProgramlamaProje.Repositories
{
	public class BaseRepository<T> : IBaseRepository<T> where T : class
	{
		private readonly Context ctx;
		public BaseRepository(Context ctx)
		{
			this.ctx = ctx;
		}
		public bool Create(T entity)
		{
			try
			{
				ctx.Set<T>().Add(entity);
				ctx.SaveChanges();
				return true;
			}
			catch (Exception ex)
			{
				return false;
			}
		}

		public bool Delete(T entity)
		{
			try
			{
				ctx.Set<T>().Remove(entity);
				ctx.SaveChanges();
				return true;
			}
			catch (Exception ex)
			{
				return false;
			}
		}
		public bool Update(T entity)
		{
			try
			{
				ctx.Set<T>().Update(entity);
				ctx.SaveChanges();
				return true;
			}
			catch (Exception ex)
			{
				return false;
			}
		}
		public T? FindById(int id)
		{
			return ctx.Set<T>().Find(id);
		}

		public IQueryable<T> GetAll()
		{
			return ctx.Set<T>().AsNoTracking();
		}

		public IQueryable<T> GetAll(Expression<Func<T, bool>> expression)
		{
			return ctx.Set<T>().Where(expression).AsNoTracking();

		}


	}
}
